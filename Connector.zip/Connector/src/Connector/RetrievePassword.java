package Connector;

import java.awt.BorderLayout;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JLabel;

import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class RetrievePassword extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField txtNihao;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RetrievePassword frame = new RetrievePassword();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RetrievePassword() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel label = new JLabel("");
		
		JLabel lblPleaseEnterYour = new JLabel("Please enter your username:");
		lblPleaseEnterYour.setFont(new Font("Apple LiSung", Font.PLAIN, 16));
		
		JLabel lblYouPasswordIs = new JLabel("You password is:");
		lblYouPasswordIs.setFont(new Font("Apple LiSung", Font.PLAIN, 16));
		
		txtNihao = new JTextField();
		txtNihao.setForeground(SystemColor.windowBorder);
		txtNihao.setText("password");
		txtNihao.setColumns(10);
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JButton btnEnter = new JButton("Enter");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String UserName = textField.getText();
				Connection con;
			    Statement statement;
			    ResultSet rs;
			    
				String driver = "com.mysql.cj.jdbc.Driver";
				String url = "jdbc:mysql://teddydatabase.cnigeahsjz2r.us-east-2.rds.amazonaws.com:3306/Watchdogs?serverTimezone=UTC&autoReconnect=true&useSSL=false";
				String user = "Watchdogs";
				String password = "12345678";
				try {
					Class.forName(driver);
					con = DriverManager.getConnection(url,user,password);
					
					if(!con.isClosed()) {
						System.out.println("Succeed conncet to database.");
					}
					statement = con.createStatement();
					String sql = "SELECT Password FROM User WHERE UserName='"+UserName+"'";
					rs = statement.executeQuery(sql); 
					rs.next();
					String PassWord = rs.getString("Password");
					txtNihao.setForeground(SystemColor.windowText);
					txtNihao.setText(PassWord);
					
				} catch (ClassNotFoundException E) {
					System.out.println("Sorry, can't find the Driver!");
					E.printStackTrace();
		      
				} catch (SQLException E) {
					E.printStackTrace();
		      
				} catch (Exception E) {
					E.printStackTrace();
		      
				} finally {
					System.out.println("Success!");
				}
			}
		});
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage2 MainPage = new MainPage2();
				MainPage.setVisible(true);
			}
		});
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(145)
							.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(174)
							.addComponent(btnEnter))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(176)
							.addComponent(label))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(126)
							.addComponent(lblPleaseEnterYour))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(81)
							.addComponent(lblYouPasswordIs)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(txtNihao, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(105, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(317, Short.MAX_VALUE)
					.addComponent(btnNewButton)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(24)
					.addComponent(label)
					.addGap(17)
					.addComponent(lblPleaseEnterYour)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnEnter)
					.addGap(53)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(txtNihao, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblYouPasswordIs))
					.addGap(18)
					.addComponent(btnNewButton)
					.addContainerGap(17, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

}
